<?php

$con = mysqli_connect('localhost', 'root', '', 'lab_automation');

if (!$con) {
    echo 'Connection Failed';
}
// else {
//     echo 'Connection Failed';
// }
?>
